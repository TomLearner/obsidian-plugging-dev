import { PresetSample } from '../types';

export const PRESET_SAMPLES: PresetSample[] = [
  {
    id: 'conjugate-base-prompt',
    title: 'Conjugate Base (User Example)',
    badge: 'Exact User Prompt',
    description: 'The exact acid-base chemistry note with duplicate prefixes, \\boxed{}, \\mathrm{}, and inline H+H^+ tokens.',
    content: `## How to understand **Conjugate Base**

The easiest way to understand **conjugate base** is:

> **When an acid donates a proton (H⁺), the species left behind is its conjugate base.**

The key is **loss of H⁺**.

### 1. Start with an acid

Take acetic acid:

CH3COOH\\mathrm{CH_3COOH}

It can donate a proton:

CH3COOH→H++CH3COO−\\mathrm{CH_3COOH \\rightarrow H^+ + CH_3COO^-}

The original acid is:

CH3COOH\\boxed{\\mathrm{CH_3COOH}}

After it loses H+H^+, what remains is:

CH3COO−\\boxed{\\mathrm{CH_3COO^-}}

Therefore:

CH3COO−=conjugate base of CH3COOH\\boxed{\\mathrm{CH_3COO^-}=\\text{conjugate base of }\\mathrm{CH_3COOH}}

---

## 2. Why is it called a "base"?

This comes from the **Brønsted–Lowry definition**:

- **Acid** = proton donor
    
- **Base** = proton acceptor
    

So after an acid loses H+H^+, its conjugate base can potentially **accept H+H^+ back**.

For example:

CH3COOH⇌H++CH3COO−\\mathrm{CH_3COOH \\rightleftharpoons H^+ + CH_3COO^-}

The reverse reaction is:

CH3COO−+H+→CH3COOH\\mathrm{CH_3COO^- + H^+ \\rightarrow CH_3COOH}

Therefore, CH3COO−\\mathrm{CH_3COO^-} behaves as a base because it can accept a proton.

---

# 3. A very useful formula

If you have an acid:

HA\\boxed{\\mathrm{HA}}

and it loses a proton:

HA→H++A−\\mathrm{HA \\rightarrow H^+ + A^-}

then:

HA=acid\\boxed{\\mathrm{HA = acid}} A−=conjugate base\\boxed{\\mathrm{A^- = conjugate\\ base}}

So:

> **Conjugate base = acid − H⁺**

This is probably the single most useful way to remember it.

---

## 4. Another example: H₂O

Water can also act as an acid.

H2O→H++OH−\\mathrm{H_2O \\rightarrow H^+ + OH^-}

Water loses H+H^+:

H2O−H+=OH−\\mathrm{H_2O - H^+ = OH^-}

Therefore:

OH−\\boxed{\\mathrm{OH^-}}

is the **conjugate base of H₂O**.

---

## 5. Another important example: HCl

HCl→H++Cl−\\mathrm{HCl \\rightarrow H^+ + Cl^-}

Remove H+H^+:

HCl−H+=Cl−\\mathrm{HCl-H^+=Cl^-}

Therefore:

Cl−\\boxed{\\mathrm{Cl^-}}

is the conjugate base of HCl.

This gives you a useful pattern:

|Acid|Loses H+H^+|Conjugate base|
|---|---|---|
|HCl|− H⁺|Cl⁻|
|H₂O|− H⁺|OH⁻|
|CH₃COOH|− H⁺|CH₃COO⁻|
|NH₄⁺|− H⁺|NH₃|

---

# 6. Why does the charge change?

This is another important point.

Suppose:

HA\\mathrm{HA}

is neutral.

If it loses:

H+\\mathrm{H^+}

you have removed a **positive charge**.

Therefore, the remaining species becomes one unit more negative:

HA0→A−\\boxed{\\mathrm{HA^0 \\rightarrow A^-}}

For example:

HCl0→Cl−\\boxed{\\mathrm{HCl^0 \\rightarrow Cl^-}}

Similarly:

NH4+→NH3\\mathrm{NH_4^+ \\rightarrow NH_3}

Here the original species has +1+1 charge. Removing H+H^+ removes one positive charge:

+1−+1=0+1-+1=0

so NH₃ is neutral.

---

# 7. The relationship between acid and conjugate base

They always differ by **exactly one proton**:

Acid⇌Conjugate Base+H+\\boxed{\\mathrm{Acid \\rightleftharpoons Conjugate\\ Base + H^+}}

For example:

H2CO3⇌HCO3−+H+\\mathrm{H_2CO_3 \\rightleftharpoons HCO_3^- + H^+}

Therefore:

H2CO3/HCO3−\\boxed{\\mathrm{H_2CO_3/HCO_3^-}}

are a **conjugate acid–base pair**.

Another proton can be removed:

HCO3−⇌CO32−+H+\\mathrm{HCO_3^- \\rightleftharpoons CO_3^{2-}+H^+}

Now:

HCO3−\\boxed{\\mathrm{HCO_3^-}}

is the acid, while:

CO32−\\boxed{\\mathrm{CO_3^{2-}}}

is its conjugate base.

So the same molecule can sometimes act as either an acid or a base depending on the reaction.

---

## 8. The most important mental model

Think of a proton as a **transferable H⁺**:

\`\`\`text
             loses H⁺
Acid  ─────────────────→  Conjugate Base
                              
HA  ───────────────────→  A⁻
        H⁺
\`\`\`

And the reverse:

\`\`\`text
Conjugate Base  +  H⁺  →  Acid
\`\`\`

So:

Acid loses H⁺→Conjugate Base\\boxed{ \\text{Acid loses H⁺} \\rightarrow \\text{Conjugate Base} }

while:

Base gains H⁺→Conjugate Acid\\boxed{ \\text{Base gains H⁺} \\rightarrow \\text{Conjugate Acid} }

### One-line memory rule

> **Conjugate base = what remains after an acid loses one H⁺.**

Once you understand this, **conjugate acid** is simply the reverse idea: **what a base becomes after gaining one H⁺**.`
  },
  {
    id: 'physics-sample',
    title: 'Physics & Bracket Delimiters',
    badge: 'Brackets & Equations',
    description: 'Kinematics and electromagnetism with \\[ \\] and \\( \\) delimiters and duplicate prefixes.',
    content: `## Kinematics & Field Theory Notes

Here are the basic equations of motion:

\\[ v = v_0 + at \\]

The displacement formula when acceleration is constant:

\\[ x = x_0 + v_0 t + \\frac{1}{2} a t^2 \\]

Notice that velocity \\( v \\) depends linearly on time \\( t \\).

Also, the kinetic energy:

Ek=12mv2\\boxed{E_k = \\frac{1}{2} m v^2}

And momentum conservation:

p=mv\\boxed{p = mv}

In electromagnetic induction, Faraday's law states:

\\[ \\mathcal{E} = -\\frac{d\\Phi_B}{dt} \\]`
  },
  {
    id: 'machine-learning-sample',
    title: 'Machine Learning & Calculus',
    badge: 'Cross-Entropy & Gradients',
    description: 'Machine learning formulas copied from ChatGPT with sums, fractions, and logarithms.',
    content: `## Cross-Entropy Loss and Softmax

For multi-class classification with C classes:

L=−∑i=1Cyi⁡log⁡(y^i)\\boxed{\\mathcal{L} = -\\sum_{i=1}^C y_i \\log(\\hat{y}_i)}

Where the predicted probability is given by Softmax:

y^i=ezi∑j=1Cezj\\boxed{\\hat{y}_i = \\frac{e^{z_i}}{\\sum_{j=1}^C e^{z_j}}}

Gradient of the loss with respect to logit \\( z_i \\):

\\frac{\\partial \\mathcal{L}}{\\partial z_i} = \\hat{y}_i - y_i

Let us check the derivative step by step.`
  }
];
