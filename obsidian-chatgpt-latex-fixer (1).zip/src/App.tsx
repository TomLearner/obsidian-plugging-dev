/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { EditorPane } from './components/EditorPane';
import { PreviewPane } from './components/PreviewPane';
import { PluginModal } from './components/PluginModal';
import { PRESET_SAMPLES } from './data/samples';
import { convertChatGptToObsidian, DEFAULT_OPTIONS } from './utils/latexParser';
import { ConverterOptions } from './types';

export default function App() {
  const [input, setInput] = useState<string>(PRESET_SAMPLES[0].content);
  const [activePresetId, setActivePresetId] = useState<string | null>(PRESET_SAMPLES[0].id);
  const [options, setOptions] = useState<ConverterOptions>(DEFAULT_OPTIONS);
  const [copied, setCopied] = useState(false);
  const [isPluginModalOpen, setIsPluginModalOpen] = useState(false);

  // Real-time conversion
  const { output, stats, logs } = useMemo(() => {
    return convertChatGptToObsidian(input, options);
  }, [input, options]);

  const handleLoadPreset = (id: string) => {
    const sample = PRESET_SAMPLES.find((s) => s.id === id);
    if (sample) {
      setInput(sample.content);
      setActivePresetId(sample.id);
    }
  };

  const handleInputChange = (val: string) => {
    setInput(val);
    setActivePresetId(null);
  };

  const handleCopyResult = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const handleDownloadMarkdown = () => {
    if (!output) return;
    const blob = new Blob([output], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'obsidian-repaired-note.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar
        stats={stats}
        onConvert={() => {
          // Force re-evaluation
          setInput((prev) => prev);
        }}
        onCopyResult={handleCopyResult}
        onDownloadMarkdown={handleDownloadMarkdown}
        onOpenPluginModal={() => setIsPluginModalOpen(true)}
        copied={copied}
      />

      {/* Main Workspace Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-4 grid grid-cols-1 lg:grid-cols-2 gap-4 items-stretch">
        {/* Left Pane: Input Editor & Presets */}
        <div className="h-[calc(100vh-80px)] min-h-[500px]">
          <EditorPane
            input={input}
            onChange={handleInputChange}
            options={options}
            onOptionsChange={setOptions}
            onLoadPreset={handleLoadPreset}
            activePresetId={activePresetId}
          />
        </div>

        {/* Right Pane: Obsidian Preview, Output, Diff, and Plugin exporter */}
        <div className="h-[calc(100vh-80px)] min-h-[500px]">
          <PreviewPane
            output={output}
            originalInput={input}
            stats={stats}
            logs={logs}
            onCopyResult={handleCopyResult}
            copied={copied}
          />
        </div>
      </main>

      {/* Obsidian Plugin Downloader Modal */}
      <PluginModal
        isOpen={isPluginModalOpen}
        onClose={() => setIsPluginModalOpen(false)}
      />
    </div>
  );
}
