export interface ConversionStats {
  totalFixes: number;
  blockEquationsFixed: number;
  inlineEquationsFixed: number;
  duplicatePrefixesRemoved: number;
  bracketDelimitersFixed: number;
  tableFormulasFixed: number;
  timeTakenMs: number;
}

export interface FixLogItem {
  id: string;
  type: 'block' | 'inline' | 'bracket' | 'table';
  original: string;
  fixed: string;
  lineNumber: number;
  explanation: string;
}

export interface ConverterOptions {
  wrapStandaloneBlocks: boolean;
  fixInlineDuplicates: boolean;
  convertBracketDelimiters: boolean;
  cleanDuplicatePrefixes: boolean;
  normalizeUnicodeMinus: boolean;
  formatTables: boolean;
  addSpaceAroundInline: boolean;
  displayStyle: 'double-newline' | 'single-line';
}

export interface PresetSample {
  id: string;
  title: string;
  badge: string;
  description: string;
  content: string;
}
