import JSZip from 'jszip';

export const PLUGIN_MANIFEST = {
  id: "chatgpt-latex-fixer",
  name: "ChatGPT LaTeX Fixer",
  version: "1.0.0",
  minAppVersion: "0.15.0",
  description: "Automatically detect and convert broken/duplicate formulas copied from ChatGPT into standard LaTeX for Obsidian.",
  author: "Obsidian Community",
  authorUrl: "https://github.com",
  isDesktopOnly: false
};

export const PLUGIN_CSS = `/* ChatGPT LaTeX Fixer plugin styles */
.chatgpt-latex-fixer-ribbon-icon {
  color: var(--interactive-accent);
}

.chatgpt-latex-status-item {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 11px;
  color: var(--text-muted);
}
`;

export const PLUGIN_MAIN_JS = `/*
 * ChatGPT LaTeX Fixer for Obsidian
 * Automatically detect and convert broken/duplicate formulas copied from ChatGPT into standard LaTeX.
 */
const { Plugin, PluginSettingTab, Setting, Notice } = require('obsidian');

const DEFAULT_SETTINGS = {
  autoFixOnPaste: true,
  wrapStandaloneBlocks: true,
  fixInlineDuplicates: true,
  convertBracketDelimiters: true,
  cleanDuplicatePrefixes: true,
  displayStyle: 'single-line',
  showNotificationOnFix: true
};

function normalizeForComparison(str) {
  return str
    .replace(/\\u00A0/g, ' ')
    .replace(/[−–—]/g, '-')
    .replace(/→/g, '\\\\rightarrow')
    .replace(/⇌/g, '\\\\rightleftharpoons')
    .replace(/↔/g, '\\\\leftrightarrow')
    .replace(/[\\s\\r\\n]+/g, '')
    .toLowerCase();
}

function stripLatexToText(latex) {
  return latex
    .replace(/\\\\[a-zA-Z]+/g, '')
    .replace(/[{}^_\\\\]/g, '')
    .replace(/[−–—]/g, '-')
    .replace(/\\u00A0/g, ' ')
    .replace(/[\\s\\r\\n]+/g, '')
    .toLowerCase();
}

function extractBalancedLatexCommand(text, startIdx) {
  if (text[startIdx] !== '\\\\') return null;
  const cmdMatch = text.slice(startIdx).match(/^\\\\([a-zA-Z]+|\\S)/);
  if (!cmdMatch) return null;

  let pos = startIdx + cmdMatch[0].length;
  while (pos < text.length && /\\s/.test(text[pos])) pos++;

  if (pos < text.length && (text[pos] === '{' || text[pos] === '[')) {
    while (pos < text.length && (text[pos] === '{' || text[pos] === '[')) {
      const openChar = text[pos];
      const closeChar = openChar === '{' ? '}' : ']';
      let depth = 1;
      pos++;
      while (pos < text.length && depth > 0) {
        if (text[pos] === '\\\\') {
          pos += 2;
          continue;
        }
        if (text[pos] === openChar) depth++;
        else if (text[pos] === closeChar) depth--;
        pos++;
      }
      while (pos < text.length && /\\s/.test(text[pos])) pos++;
    }
    return {
      command: text.substring(startIdx, pos).trim(),
      endIdx: pos
    };
  }

  return {
    command: cmdMatch[0],
    endIdx: startIdx + cmdMatch[0].length
  };
}

function fixInlineDuplicateToken(token) {
  if (token.includes('$')) return null;

  // Pattern for duplicated signed number like +1+1
  const signedDup = token.match(/^([+\\-−]\\d+)\\1$/);
  if (signedDup) {
    return \`$\${signedDup[1].replace(/[−–—]/g, '-')}$\`;
  }

  if (!token.includes('^') && !token.includes('_') && !token.includes('\\\\') && !token.includes('=')) {
    return null;
  }

  const len = token.length;
  for (let i = 1; i < len; i++) {
    const left = token.slice(0, i);
    const right = token.slice(i);

    if (!right.includes('^') && !right.includes('_') && !right.includes('\\\\') && !right.includes('=')) {
      continue;
    }

    const normLeft = normalizeForComparison(left);
    const normRight = normalizeForComparison(stripLatexToText(right));
    const plainLeft = left.replace(/[−–—]/g, '-');
    const plainRight = right.replace(/[−–—]/g, '-').replace(/[{}^_\\\\]/g, '');

    if (normLeft === normRight || plainLeft === plainRight) {
      return \`$\${right}$\`;
    }
  }
  return null;
}

function convertChatGptToObsidianCore(input, settings) {
  if (!input || !input.trim()) return { text: input, fixedCount: 0 };
  let fixCount = 0;

  // Mask code blocks
  const codeBlocks = [];
  let processed = input.replace(/(\`\`\`[\\s\\S]*?\`\`\`|\`[^\`\\n]+\`)/g, (m) => {
    const p = \`__PROTECTED_CODE_\${codeBlocks.length}__\`;
    codeBlocks.push(m);
    return p;
  });

  // Mask existing math
  const mathBlocks = [];
  processed = processed.replace(/(\\$\\$[\\s\\S]*?\\$\\$|\\$(?!\\s)[^$\\n]+(?<!\\s)\\$)/g, (m) => {
    const p = \`__PROTECTED_MATH_\${mathBlocks.length}__\`;
    mathBlocks.push(m);
    return p;
  });

  // Convert bracket delimiters
  if (settings.convertBracketDelimiters) {
    processed = processed.replace(/\\\\\\[([\\s\\S]*?)\\\\\\]/g, (_, inner) => {
      fixCount++;
      return \`$$\\n\${inner.trim()}\\n$$\`;
    });
    processed = processed.replace(/\\\\\\(([\\s\\S]*?)\\\\\\)/g, (_, inner) => {
      fixCount++;
      return \`$\${inner.trim()}$\`;
    });
  }

  const lines = processed.split('\\n');
  const resultLines = [];

  for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
    const rawLine = lines[lineIdx];
    let line = rawLine;

    if (!line.trim() || line.trim() === '---' || line.trim().startsWith('#')) {
      resultLines.push(line);
      continue;
    }

    const isTableRow = line.trim().startsWith('|') && line.trim().endsWith('|');

    // Standalone block formulas with ChatGPT duplicated prefix
    if (!isTableRow && settings.cleanDuplicatePrefixes && settings.wrapStandaloneBlocks) {
      const firstBs = line.indexOf('\\\\');
      if (firstBs > 0) {
        let searchPos = 0;
        let isAllFormulas = true;
        const items = [];

        while (searchPos < line.length) {
          const bsIndex = line.indexOf('\\\\', searchPos);
          if (bsIndex === -1) {
            if (line.slice(searchPos).trim().length > 0) isAllFormulas = false;
            break;
          }
          const prefix = line.substring(searchPos, bsIndex).trim();
          const parsed = extractBalancedLatexCommand(line, bsIndex);
          if (!parsed) {
            searchPos = bsIndex + 1;
            continue;
          }

          const isMathCmd = /^(boxed|mathrm|mathbf|mathit|text|textbf|frac|sqrt|displaystyle|sum|int|begin)/.test(
            parsed.command.replace(/^\\\\/, '')
          );

          if (isMathCmd) {
            items.push({ prefix, latex: parsed.command });
            searchPos = parsed.endIdx;
            while (searchPos < line.length && /\\s/.test(line[searchPos])) searchPos++;
          } else {
            isAllFormulas = false;
            searchPos = parsed.endIdx;
          }
        }

        if (items.length > 0 && isAllFormulas) {
          const latexParts = items.map((it) => it.latex).join(' \\\\quad ');
          const formattedBlock = settings.displayStyle === 'double-newline'
            ? \`$$\\n\${latexParts}\\n$$\`
            : \`$$\${latexParts}$$\`;
          fixCount++;
          resultLines.push(formattedBlock);
          continue;
        }
      }

      // Standalone line starting with LaTeX command
      if (line.trim().startsWith('\\\\') && !line.includes('$')) {
        const parsed = extractBalancedLatexCommand(line.trim(), 0);
        if (parsed && parsed.endIdx >= line.trim().length - 1) {
          const formattedBlock = settings.displayStyle === 'double-newline'
            ? \`$$\\n\${line.trim()}\\n$$\`
            : \`$$\${line.trim()}$$\`;
          fixCount++;
          resultLines.push(formattedBlock);
          continue;
        }
      }

      // Standalone equation line like +1−+1=0+1-+1=0
      const trimmed = line.trim();
      const equationDup = fixInlineDuplicateToken(trimmed);
      if (equationDup && trimmed.includes('=')) {
        fixCount++;
        resultLines.push(\`$$\${equationDup.replace(/^\\$|\\$$/g, '')}$$\`);
        continue;
      }
    }

    // Inline formula repair
    if (settings.fixInlineDuplicates) {
      const tokenRegex = /(\\s+|\\||\\*\\*|__|\\*|_|\\(|\\)|\\[|\\]|,|;|:)/;
      const parts = line.split(tokenRegex);
      let lineModified = false;

      const newParts = parts.map((token) => {
        if (!token || tokenRegex.test(token)) return token;

        const fixedToken = fixInlineDuplicateToken(token);
        if (fixedToken) {
          lineModified = true;
          fixCount++;
          return fixedToken;
        }

        if (/^[A-Za-z0-9]+[\\^_]\\{?[A-Za-z0-9+\\-−]+\\}?$/.test(token) && !token.startsWith('$') && !token.endsWith('$')) {
          lineModified = true;
          fixCount++;
          return \`$\${token.replace(/[−–—]/g, '-')}$\`;
        }

        return token;
      });

      if (lineModified) {
        line = newParts.join('');
      }
    }

    resultLines.push(line);
  }

  let finalOutput = resultLines.join('\\n');

  finalOutput = finalOutput.replace(/__PROTECTED_MATH_(\\d+)__/g, (_, idx) => {
    return mathBlocks[parseInt(idx, 10)] || '';
  });

  finalOutput = finalOutput.replace(/__PROTECTED_CODE_(\\d+)__/g, (_, idx) => {
    return codeBlocks[parseInt(idx, 10)] || '';
  });

  return { text: finalOutput, fixedCount: fixCount };
}

class ChatGptLatexFixerPlugin extends Plugin {
  async onload() {
    await this.loadSettings();

    // Add ribbon icon
    this.addRibbonIcon('function-square', 'Fix ChatGPT LaTeX in current note', () => {
      this.fixCurrentNote();
    });

    // Command: Fix entire note
    this.addCommand({
      id: 'fix-chatgpt-latex-current-note',
      name: 'Fix ChatGPT LaTeX in current note (修复当前笔记中的 ChatGPT 公式)',
      editorCallback: (editor, view) => {
        this.fixEditorContent(editor);
      }
    });

    // Command: Fix selected text
    this.addCommand({
      id: 'fix-chatgpt-latex-selection',
      name: 'Fix ChatGPT LaTeX in selection (修复选中区域中的 ChatGPT 公式)',
      editorCallback: (editor, view) => {
        const selection = editor.getSelection();
        if (!selection) {
          new Notice('Please select text containing ChatGPT formulas first.');
          return;
        }
        const { text, fixedCount } = convertChatGptToObsidianCore(selection, this.settings);
        editor.replaceSelection(text);
        if (this.settings.showNotificationOnFix) {
          new Notice(\`Repaired \${fixedCount} ChatGPT formula(s) in selection.\`);
        }
      }
    });

    // Auto-fix on paste handler
    this.registerEvent(
      this.app.workspace.on('editor-paste', (evt, editor, view) => {
        if (!this.settings.autoFixOnPaste) return;

        const clipboardText = evt.clipboardData ? evt.clipboardData.getData('text/plain') : '';
        if (!clipboardText) return;

        // Quick heuristic check: contains backslash math command or duplicate formula token
        const hasChatGptPattern =
          /\\[a-zA-Z]+\{/.test(clipboardText) ||
          /\\b[A-Za-z0-9]+\\^[A-Za-z0-9+\\-]+\\b/.test(clipboardText) ||
          /\\\\(\\[|\\()/.test(clipboardText);

        if (hasChatGptPattern) {
          const { text, fixedCount } = convertChatGptToObsidianCore(clipboardText, this.settings);
          if (fixedCount > 0) {
            evt.preventDefault();
            editor.replaceSelection(text);
            if (this.settings.showNotificationOnFix) {
              new Notice(\`Auto-repaired \${fixedCount} ChatGPT formula(s) on paste!\`);
            }
          }
        }
      })
    );

    this.addSettingTab(new ChatGptLatexSettingTab(this.app, this));
  }

  fixCurrentNote() {
    const activeView = this.app.workspace.getActiveViewOfType(require('obsidian').MarkdownView);
    if (!activeView) {
      new Notice('No active markdown note found.');
      return;
    }
    this.fixEditorContent(activeView.editor);
  }

  fixEditorContent(editor) {
    const content = editor.getValue();
    const { text, fixedCount } = convertChatGptToObsidianCore(content, this.settings);
    if (fixedCount > 0) {
      editor.setValue(text);
      if (this.settings.showNotificationOnFix) {
        new Notice(\`Success! Fixed \${fixedCount} ChatGPT formula(s) in this note.\`);
      }
    } else {
      if (this.settings.showNotificationOnFix) {
        new Notice('No broken ChatGPT formulas detected in this note.');
      }
    }
  }

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }
}

class ChatGptLatexSettingTab extends PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl('h2', { text: 'ChatGPT LaTeX Fixer Settings' });

    new Setting(containerEl)
      .setName('Auto-fix on Paste (粘贴时自动修复)')
      .setDesc('Automatically intercept clipboard paste, detect ChatGPT formula anomalies, and convert them to standard LaTeX.')
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.autoFixOnPaste).onChange(async (val) => {
          this.plugin.settings.autoFixOnPaste = val;
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName('Clean Duplicate Text Prefixes (清理重复文本前缀)')
      .setDesc('Remove DOM KaTeX fallback text prepended to LaTeX formulas (e.g. "CH3COOH\\\\mathrm{CH_3COOH}" -> "$$\\\\mathrm{CH_3COOH}$$").')
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.cleanDuplicatePrefixes).onChange(async (val) => {
          this.plugin.settings.cleanDuplicatePrefixes = val;
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName('Fix Inline Duplicate Tokens (修复行内重复公式)')
      .setDesc('Fix inline duplicated superscript/subscript artifacts like "H+H^+" -> "$H^+$" and table entries.')
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.fixInlineDuplicates).onChange(async (val) => {
          this.plugin.settings.fixInlineDuplicates = val;
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName('Convert Bracket Delimiters (转换 \\[ \\] 和 \\( \\))')
      .setDesc('Convert LaTeX bracket delimiters \\\\[ ... \\\\] to $$ and \\\\( ... \\\\) to $.')
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.convertBracketDelimiters).onChange(async (val) => {
          this.plugin.settings.convertBracketDelimiters = val;
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName('Display Math Style (公式块格式)')
      .setDesc('Choose whether display math is wrapped in single-line $$...$$ or multi-line $$\\n...\\n$$.')
      .addDropdown((dropdown) =>
        dropdown
          .addOption('single-line', 'Single-line ($$...$$)')
          .addOption('double-newline', 'Multi-line ($$\\n...\\n$$)')
          .setValue(this.plugin.settings.displayStyle)
          .onChange(async (val) => {
            this.plugin.settings.displayStyle = val;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName('Show Notification Notice (显示修复通知)')
      .setDesc('Display an Obsidian pop-up notice showing how many formulas were repaired.')
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.showNotificationOnFix).onChange(async (val) => {
          this.plugin.settings.showNotificationOnFix = val;
          await this.plugin.saveSettings();
        })
      );
  }
}

module.exports = ChatGptLatexFixerPlugin;
`;

export async function generatePluginZip(): Promise<Blob> {
  const zip = new JSZip();
  const folder = zip.folder('obsidian-chatgpt-latex-fixer') || zip;
  folder.file('manifest.json', JSON.stringify(PLUGIN_MANIFEST, null, 2));
  folder.file('main.js', PLUGIN_MAIN_JS);
  folder.file('styles.css', PLUGIN_CSS);
  folder.file(
    'README.md',
    `# ChatGPT LaTeX Fixer for Obsidian

Solve the issue of formulas copied from ChatGPT failing to display in Obsidian by automatically identifying and converting them into standard LaTeX format.

## Installation

1. Create a folder named \`obsidian-chatgpt-latex-fixer\` in your vault's \`.obsidian/plugins/\` directory.
2. Place \`manifest.json\`, \`main.js\`, and \`styles.css\` inside that folder.
3. Open Obsidian, go to **Settings -> Community plugins**, turn off Restricted mode if prompted, and click **Reload**.
4. Toggle **ChatGPT LaTeX Fixer** to ON.

## Usage

- **Auto-Fix on Paste**: When enabled, copying and pasting ChatGPT text into your note will automatically repair broken formulas.
- **Command Palette (Ctrl/Cmd + P)**:
  - \`Fix ChatGPT LaTeX in current note\`: Repairs all formulas in the current note.
  - \`Fix ChatGPT LaTeX in selection\`: Repairs only the highlighted text.
- **Ribbon Icon**: Click the math square icon in Obsidian's left ribbon to quickly fix the active note.
`
  );

  return await zip.generateAsync({ type: 'blob' });
}
