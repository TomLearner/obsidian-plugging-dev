import { ConverterOptions, ConversionStats, FixLogItem } from '../types';

export const DEFAULT_OPTIONS: ConverterOptions = {
  wrapStandaloneBlocks: true,
  fixInlineDuplicates: true,
  convertBracketDelimiters: true,
  cleanDuplicatePrefixes: true,
  normalizeUnicodeMinus: true,
  formatTables: true,
  addSpaceAroundInline: false,
  displayStyle: 'single-line',
};

/**
 * Normalizes string for comparison between KaTeX rendered HTML text and LaTeX source.
 */
function normalizeForComparison(str: string): string {
  return str
    .replace(/\u00A0/g, ' ') // non-breaking spaces
    .replace(/[−–—]/g, '-')   // unicode minuses/dashes
    .replace(/→/g, '\\rightarrow')
    .replace(/⇌/g, '\\rightleftharpoons')
    .replace(/↔/g, '\\leftrightarrow')
    .replace(/[\s\r\n]+/g, '')
    .toLowerCase();
}

/**
 * Strips LaTeX command markup to compare against plain text fallback.
 */
function stripLatexToText(latex: string): string {
  return latex
    .replace(/\\[a-zA-Z]+/g, '') // remove commands like \mathrm, \boxed, \text
    .replace(/[{}^_\\]/g, '')     // remove braces, superscripts, subscripts, backslashes
    .replace(/[−–—]/g, '-')
    .replace(/\u00A0/g, ' ')
    .replace(/[\s\r\n]+/g, '')
    .toLowerCase();
}

/**
 * Extracts a balanced LaTeX command starting with `\command{...}`.
 * Returns the full command with arguments and end index.
 */
function extractBalancedLatexCommand(text: string, startIdx: number): { command: string; endIdx: number } | null {
  if (text[startIdx] !== '\\') return null;

  // Match command name like \boxed, \mathrm, \frac, etc.
  const cmdMatch = text.slice(startIdx).match(/^\\([a-zA-Z]+|\S)/);
  if (!cmdMatch) return null;

  let pos = startIdx + cmdMatch[0].length;

  // Skip optional whitespace
  while (pos < text.length && /\s/.test(text[pos])) pos++;

  // If followed by '{' or '[' (arguments)
  if (pos < text.length && (text[pos] === '{' || text[pos] === '[')) {
    while (pos < text.length && (text[pos] === '{' || text[pos] === '[')) {
      const openChar = text[pos];
      const closeChar = openChar === '{' ? '}' : ']';
      let depth = 1;
      pos++;

      while (pos < text.length && depth > 0) {
        if (text[pos] === '\\') {
          pos += 2; // skip escaped characters like \{ or \}
          continue;
        }
        if (text[pos] === openChar) depth++;
        else if (text[pos] === closeChar) depth--;
        pos++;
      }
      // Skip optional whitespace before another argument (e.g. \frac{a}{b})
      while (pos < text.length && /\s/.test(text[pos])) pos++;
    }
    return {
      command: text.substring(startIdx, pos).trim(),
      endIdx: pos,
    };
  }

  // Standalone command like \rightleftharpoons, \rightarrow, \alpha, \sum
  return {
    command: cmdMatch[0],
    endIdx: startIdx + cmdMatch[0].length,
  };
}

/**
 * Checks if a string has a duplicated inline pattern like `H+H^+` or `+1−+1=0+1-+1=0`.
 */
function fixInlineDuplicateToken(token: string): string | null {
  // If token already has $, do not touch
  if (token.includes('$')) return null;

  // Must contain some math marker in the right half like ^, _, \, or =
  if (!token.includes('^') && !token.includes('_') && !token.includes('\\') && !token.includes('=')) {
    return null;
  }

  const len = token.length;
  // Try split points between 1 and len-1
  for (let i = 1; i < len; i++) {
    const left = token.slice(0, i);
    const right = token.slice(i);

    // Right side must look like LaTeX
    if (!right.includes('^') && !right.includes('_') && !right.includes('\\') && !right.includes('=')) {
      continue;
    }

    const normLeft = normalizeForComparison(left);
    const normRight = normalizeForComparison(stripLatexToText(right));

    // Also check direct text equivalence if unicode minus was used
    const plainLeft = left.replace(/[−–—]/g, '-');
    const plainRight = right.replace(/[−–—]/g, '-').replace(/[{}^_\\]/g, '');

    if (normLeft === normRight || plainLeft === plainRight) {
      return `$${right}$`;
    }
  }

  return null;
}

/**
 * Main function to transform raw ChatGPT copied markdown into standard LaTeX format for Obsidian.
 */
export function convertChatGptToObsidian(
  input: string,
  options: ConverterOptions = DEFAULT_OPTIONS
): {
  output: string;
  stats: ConversionStats;
  logs: FixLogItem[];
} {
  const startTime = performance.now();
  const logs: FixLogItem[] = [];
  let blockCount = 0;
  let inlineCount = 0;
  let prefixCount = 0;
  let bracketCount = 0;
  let tableCount = 0;

  if (!input || !input.trim()) {
    return {
      output: '',
      stats: {
        totalFixes: 0,
        blockEquationsFixed: 0,
        inlineEquationsFixed: 0,
        duplicatePrefixesRemoved: 0,
        bracketDelimitersFixed: 0,
        tableFormulasFixed: 0,
        timeTakenMs: 0,
      },
      logs: [],
    };
  }

  // 1. MASK CODE BLOCKS (Fenced ``` ... ``` and inline `...`)
  const codeBlocks: string[] = [];
  let processed = input.replace(/(```[\s\S]*?```|`[^`\n]+`)/g, (match) => {
    const placeholder = `__PROTECTED_CODE_${codeBlocks.length}__`;
    codeBlocks.push(match);
    return placeholder;
  });

  // 2. MASK EXISTING VALID MATH ($$...$$ and $...$)
  const mathBlocks: string[] = [];
  processed = processed.replace(/(\$\$[\s\S]*?\$\$|\$(?!\s)[^$\n]+(?<!\s)\$)/g, (match) => {
    const placeholder = `__PROTECTED_MATH_${mathBlocks.length}__`;
    mathBlocks.push(match);
    return placeholder;
  });

  // 3. CONVERT BRACKET DELIMITERS \[ ... \] to $$ and \( ... \) to $
  if (options.convertBracketDelimiters) {
    // Block \[ ... \]
    processed = processed.replace(/\\\[([\s\S]*?)\\\]/g, (match, inner, offset) => {
      bracketCount++;
      const fixed = `$$\n${inner.trim()}\n$$`;
      logs.push({
        id: `bracket-block-${offset}`,
        type: 'bracket',
        original: match,
        fixed,
        lineNumber: processed.substring(0, offset).split('\n').length,
        explanation: 'Converted \\[ ... \\] block delimiters to Obsidian standard $$ ... $$',
      });
      return fixed;
    });

    // Inline \( ... \)
    processed = processed.replace(/\\\(([\s\S]*?)\\\)/g, (match, inner, offset) => {
      bracketCount++;
      const fixed = `$${inner.trim()}$`;
      logs.push({
        id: `bracket-inline-${offset}`,
        type: 'bracket',
        original: match,
        fixed,
        lineNumber: processed.substring(0, offset).split('\n').length,
        explanation: 'Converted \\( ... \\) inline delimiters to Obsidian standard $ ... $',
      });
      return fixed;
    });
  }

  // 4. PROCESS LINE BY LINE FOR BLOCK & INLINE FORMULAS
  const lines = processed.split('\n');
  const resultLines: string[] = [];

  for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
    const rawLine = lines[lineIdx];
    const lineNum = lineIdx + 1;
    let line = rawLine;

    // Skip empty lines, headers, horizontal rules
    if (!line.trim() || line.trim() === '---' || line.trim().startsWith('#')) {
      resultLines.push(line);
      continue;
    }

    // Check if line is a table row
    const isTableRow = line.trim().startsWith('|') && line.trim().endsWith('|');

    // A. Detect and fix block formula lines with duplicated prefix:
    // e.g. "CH3COOH\mathrm{CH_3COOH}"
    // or "CH3COOH→H++CH3COO−\mathrm{CH_3COOH \rightarrow H^+ + CH_3COO^-}"
    // or "CH3COO−=conjugate base of CH3COOH\boxed{\mathrm{CH_3COO^-}=\text{conjugate base of }\mathrm{CH_3COOH}}"
    // or "Acid loses H⁺→Conjugate Base\boxed{ \text{Acid loses H⁺} \rightarrow \text{Conjugate Base} }"
    if (!isTableRow && options.cleanDuplicatePrefixes && options.wrapStandaloneBlocks) {
      // Look for one or more \boxed{...} or \mathrm{...} or other LaTeX commands on this line
      const firstBackslash = line.indexOf('\\');
      if (firstBackslash > 0) {
        // Find all LaTeX commands on this line
        const latexSegments: { command: string; fullLatex: string; start: number; end: number }[] = [];
        let curr = 0;

        // Check for multiple commands like: HA=acid\boxed{...} A−=conjugate base\boxed{...}
        const boxedOrMathRegex = /([^\\]*?)(\\([a-zA-Z]+)\{([\s\S]*?)\})/g;
        // Let's use balanced parser for accuracy
        let searchPos = 0;
        let isAllFormulas = true;
        const items: { prefix: string; latex: string }[] = [];

        while (searchPos < line.length) {
          const bsIndex = line.indexOf('\\', searchPos);
          if (bsIndex === -1) {
            // Check remaining text
            const remaining = line.slice(searchPos).trim();
            if (remaining.length > 0) {
              isAllFormulas = false;
            }
            break;
          }

          const prefix = line.substring(searchPos, bsIndex).trim();
          const parsed = extractBalancedLatexCommand(line, bsIndex);

          if (!parsed) {
            searchPos = bsIndex + 1;
            continue;
          }

          // Check if parsed command is a typical math command
          const isMathCmd = /^(boxed|mathrm|mathbf|mathit|text|textbf|frac|sqrt|displaystyle|sum|int|begin)/.test(
            parsed.command.replace(/^\\/, '')
          );

          if (isMathCmd) {
            items.push({
              prefix,
              latex: parsed.command,
            });
            searchPos = parsed.endIdx;
            // skip spaces between items
            while (searchPos < line.length && /\s/.test(line[searchPos])) searchPos++;
          } else {
            isAllFormulas = false;
            searchPos = parsed.endIdx;
          }
        }

        // If the entire line was composed of formulas with duplicated text prefixes
        if (items.length > 0 && isAllFormulas) {
          const latexParts = items.map((it) => it.latex).join(' \\quad ');
          const formattedBlock =
            options.displayStyle === 'double-newline'
              ? `$$\n${latexParts}\n$$`
              : `$$${latexParts}$$`;

          prefixCount += items.length;
          blockCount++;
          logs.push({
            id: `block-${lineNum}`,
            type: 'block',
            original: rawLine,
            fixed: formattedBlock,
            lineNumber: lineNum,
            explanation: `Removed duplicate ChatGPT rendered prefix ("${items
              .map((i) => i.prefix)
              .filter(Boolean)
              .join(', ')}") and wrapped equation in $$ ... $$ display block.`,
          });

          resultLines.push(formattedBlock);
          continue;
        }
      }

      // Check for standalone line starting with LaTeX command (no duplicate prefix, e.g. \mathrm{...} or \boxed{...})
      if (line.trim().startsWith('\\') && !line.includes('$')) {
        const parsed = extractBalancedLatexCommand(line.trim(), 0);
        if (parsed && parsed.endIdx >= line.trim().length - 1) {
          const formattedBlock =
            options.displayStyle === 'double-newline'
              ? `$$\n${line.trim()}\n$$`
              : `$$${line.trim()}$$`;

          blockCount++;
          logs.push({
            id: `standalone-${lineNum}`,
            type: 'block',
            original: rawLine,
            fixed: formattedBlock,
            lineNumber: lineNum,
            explanation: 'Wrapped standalone LaTeX formula in $$ ... $$ display block.',
          });

          resultLines.push(formattedBlock);
          continue;
        }
      }

      // Check for standalone equation line like +1−+1=0+1-+1=0
      const trimmedLine = line.trim();
      if (trimmedLine.includes('=')) {
        const fixedEq = fixInlineDuplicateToken(trimmedLine);
        if (fixedEq) {
          const innerMath = fixedEq.replace(/^\$|\$$/g, '');
          const formattedBlock =
            options.displayStyle === 'double-newline'
              ? `$$\n${innerMath}\n$$`
              : `$$${innerMath}$$`;

          blockCount++;
          logs.push({
            id: `standalone-eq-${lineNum}`,
            type: 'block',
            original: rawLine,
            fixed: formattedBlock,
            lineNumber: lineNum,
            explanation: 'Repaired standalone duplicated equation into $$ ... $$ display block.',
          });

          resultLines.push(formattedBlock);
          continue;
        }
      }
    }

    // B. Detect and fix inline formulas like H+H^+, +1−+1=0+1-+1=0, or embedded in prose / tables
    if (options.fixInlineDuplicates) {
      // In prose or table cells, words/tokens might have duplicated math
      // Split line into tokens preserving separators (whitespace, brackets, markdown syntax, pipes)
      const tokenRegex = /(\s+|\||\*\*|__|\*|_|\(|\)|\[|\]|,|;|:)/;
      const parts = line.split(tokenRegex);

      let lineModified = false;
      const newParts = parts.map((token) => {
        if (!token || tokenRegex.test(token)) return token;

        // Try duplicate fix
        const fixedToken = fixInlineDuplicateToken(token);
        if (fixedToken) {
          lineModified = true;
          inlineCount++;
          if (isTableRow) tableCount++;
          logs.push({
            id: `inline-${lineNum}-${token}`,
            type: isTableRow ? 'table' : 'inline',
            original: token,
            fixed: fixedToken,
            lineNumber: lineNum,
            explanation: `Fixed duplicated inline ChatGPT formula token "${token}" into standard LaTeX "${fixedToken}".`,
          });
          return fixedToken;
        }

        // Check if token is a lone chemical/math formula with ^ or _ e.g. H^+ or CO_3^{2-}
        if (
          /^[A-Za-z0-9]+[\^_]\{?[A-Za-z0-9+\-−]+\}?$/.test(token) &&
          !token.startsWith('$') &&
          !token.endsWith('$')
        ) {
          lineModified = true;
          inlineCount++;
          const fixedToken = `$${token.replace(/[−–—]/g, '-')}$`;
          logs.push({
            id: `inline-math-${lineNum}-${token}`,
            type: isTableRow ? 'table' : 'inline',
            original: token,
            fixed: fixedToken,
            lineNumber: lineNum,
            explanation: `Wrapped inline formula "${token}" with standard LaTeX $ ... $ delimiters.`,
          });
          return fixedToken;
        }

        return token;
      });

      if (lineModified) {
        line = newParts.join('');
      }
    }

    resultLines.push(line);
  }

  let finalOutput = resultLines.join('\n');

  // 5. RESTORE PROTECTED MATH BLOCKS
  finalOutput = finalOutput.replace(/__PROTECTED_MATH_(\d+)__/g, (_, idx) => {
    return mathBlocks[parseInt(idx, 10)] || '';
  });

  // 6. RESTORE PROTECTED CODE BLOCKS
  finalOutput = finalOutput.replace(/__PROTECTED_CODE_(\d+)__/g, (_, idx) => {
    return codeBlocks[parseInt(idx, 10)] || '';
  });

  const endTime = performance.now();

  return {
    output: finalOutput,
    stats: {
      totalFixes: blockCount + inlineCount + bracketCount,
      blockEquationsFixed: blockCount,
      inlineEquationsFixed: inlineCount,
      duplicatePrefixesRemoved: prefixCount,
      bracketDelimitersFixed: bracketCount,
      tableFormulasFixed: tableCount,
      timeTakenMs: Math.round(endTime - startTime),
    },
    logs,
  };
}
