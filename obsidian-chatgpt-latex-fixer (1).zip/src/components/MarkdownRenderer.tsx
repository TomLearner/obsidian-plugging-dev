import React, { useMemo } from 'react';
import katex from 'katex';

interface MarkdownRendererProps {
  content: string;
}

/**
 * Renders Obsidian-flavored Markdown with KaTeX math formula rendering.
 */
export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const renderedHtml = useMemo(() => {
    if (!content) return '';

    // 1. Process math blocks ($$...$$)
    let processed = content.replace(/\$\$([\s\S]*?)\$\$/g, (_, math) => {
      try {
        const rendered = katex.renderToString(math.trim(), {
          displayMode: true,
          throwOnError: false,
        });
        return `<div class="katex-display-wrapper my-4 flex justify-center overflow-x-auto py-2">${rendered}</div>`;
      } catch (e) {
        return `<div class="katex-error text-red-400 p-2 bg-red-950/30 rounded text-sm">${math}</div>`;
      }
    });

    // 2. Process inline math ($...$)
    // Avoid matching currency like $5 or $$
    processed = processed.replace(/\$(?!\$)(.+?)(?<!\$)\$/g, (_, math) => {
      try {
        const rendered = katex.renderToString(math.trim(), {
          displayMode: false,
          throwOnError: false,
        });
        return `<span class="katex-inline px-0.5 inline-block">${rendered}</span>`;
      } catch (e) {
        return `<span class="katex-error text-red-400 text-xs">${math}</span>`;
      }
    });

    // 3. Process Code blocks (```lang ... ```)
    processed = processed.replace(/```([a-z]*)\n([\s\S]*?)```/g, (_, lang, code) => {
      return `<pre class="bg-neutral-950/80 border border-neutral-800 rounded-lg p-3 my-3 text-xs font-mono overflow-x-auto text-neutral-300"><code>${escapeHtml(code.trim())}</code></pre>`;
    });

    // 4. Process lines for Markdown headers, lists, quotes, tables, HR
    const lines = processed.split('\n');
    const htmlLines: string[] = [];
    let inTable = false;
    let tableRows: string[][] = [];

    const flushTable = () => {
      if (tableRows.length > 0) {
        const headerRow = tableRows[0];
        const bodyRows = tableRows.slice(1);
        let tableHtml = `<div class="overflow-x-auto my-4"><table class="w-full text-left text-sm border-collapse border border-neutral-800 rounded"><thead><tr class="bg-neutral-800/60 text-neutral-200">`;
        headerRow.forEach((th) => {
          tableHtml += `<th class="border border-neutral-800 px-3 py-2 font-medium">${th}</th>`;
        });
        tableHtml += `</tr></thead><tbody>`;
        bodyRows.forEach((row, rIdx) => {
          const bg = rIdx % 2 === 0 ? 'bg-neutral-900/30' : 'bg-neutral-900/70';
          tableHtml += `<tr class="${bg} hover:bg-neutral-800/40">`;
          row.forEach((td) => {
            tableHtml += `<td class="border border-neutral-800 px-3 py-2 text-neutral-300">${td}</td>`;
          });
          tableHtml += `</tr>`;
        });
        tableHtml += `</tbody></table></div>`;
        htmlLines.push(tableHtml);
        tableRows = [];
        inTable = false;
      }
    };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Table detection
      if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
        const cells = line
          .trim()
          .slice(1, -1)
          .split('|')
          .map((c) => c.trim());

        // Check if it's separator row |---|---|
        if (cells.every((c) => /^:?-+:?$/.test(c))) {
          continue;
        }

        tableRows.push(cells);
        inTable = true;
        continue;
      } else if (inTable) {
        flushTable();
      }

      // Headers
      if (line.startsWith('### ')) {
        htmlLines.push(`<h3 class="text-lg font-semibold text-neutral-100 mt-5 mb-2">${formatInline(line.slice(4))}</h3>`);
      } else if (line.startsWith('## ')) {
        htmlLines.push(`<h2 class="text-xl font-bold text-neutral-100 mt-6 mb-3 pb-1 border-b border-neutral-800">${formatInline(line.slice(3))}</h2>`);
      } else if (line.startsWith('# ')) {
        htmlLines.push(`<h1 class="text-2xl font-black text-white mt-7 mb-4">${formatInline(line.slice(2))}</h1>`);
      }
      // Horizontal Rule
      else if (line.trim() === '---') {
        htmlLines.push(`<hr class="border-neutral-800 my-6" />`);
      }
      // Blockquote
      else if (line.startsWith('> ')) {
        htmlLines.push(`<blockquote class="border-l-4 border-purple-500 bg-purple-950/20 px-4 py-2 my-3 rounded-r text-neutral-200 text-sm italic">${formatInline(line.slice(2))}</blockquote>`);
      }
      // List items
      else if (line.trim().startsWith('- ')) {
        htmlLines.push(`<li class="ml-4 list-disc text-neutral-300 text-sm my-1">${formatInline(line.trim().slice(2))}</li>`);
      }
      // Empty line
      else if (!line.trim()) {
        htmlLines.push(`<div class="h-2"></div>`);
      }
      // Regular paragraph or html blocks
      else {
        if (line.startsWith('<div class="katex-display') || line.startsWith('<pre')) {
          htmlLines.push(line);
        } else {
          htmlLines.push(`<p class="text-neutral-300 text-sm leading-relaxed my-2">${formatInline(line)}</p>`);
        }
      }
    }

    if (inTable) {
      flushTable();
    }

    return htmlLines.join('\n');
  }, [content]);

  return (
    <div
      className="obsidian-markdown-body prose prose-invert max-w-none px-6 py-5 text-neutral-200"
      dangerouslySetInnerHTML={{ __html: renderedHtml }}
    />
  );
};

function escapeHtml(str: string) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function formatInline(str: string): string {
  // Bold **text**
  str = str.replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-white">$1</strong>');
  // Italic *text*
  str = str.replace(/(?<!\*)\*(?!\*)(.*?)(?<!\*)\*(?!\*)/g, '<em class="italic text-neutral-200">$1</em>');
  // Inline code `code`
  str = str.replace(/`([^`]+)`/g, '<code class="bg-neutral-800 px-1.5 py-0.5 rounded text-xs font-mono text-purple-300">$1</code>');
  return str;
}
