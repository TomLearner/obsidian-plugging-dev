import React, { useRef } from 'react';
import { Clipboard, Trash2, Upload, BookOpen, Layers } from 'lucide-react';
import { PRESET_SAMPLES } from '../data/samples';
import { ConverterOptions } from '../types';

interface EditorPaneProps {
  input: string;
  onChange: (val: string) => void;
  options: ConverterOptions;
  onOptionsChange: (opts: ConverterOptions) => void;
  onLoadPreset: (id: string) => void;
  activePresetId: string | null;
}

export const EditorPane: React.FC<EditorPaneProps> = ({
  input,
  onChange,
  options,
  onOptionsChange,
  onLoadPreset,
  activePresetId,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        onChange(text);
      }
    } catch (e) {
      console.error('Clipboard access not granted', e);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) onChange(text);
      };
      reader.readAsText(file);
    }
  };

  const lineCount = input ? input.split('\n').length : 0;
  const wordCount = input ? input.trim().length : 0;

  return (
    <div className="flex flex-col h-full bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm">
      {/* Header bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-neutral-900/90 border-b border-neutral-800 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-amber-400"></span>
          <span className="text-xs font-semibold text-neutral-200">
            原始 ChatGPT 粘贴内容 (Source Input)
          </span>
          <span className="text-[11px] text-neutral-500 font-mono">
            {lineCount} 行 · {wordCount} 字符
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            id="btn-paste-clipboard"
            onClick={handlePaste}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs transition-colors"
            title="从剪贴板粘贴"
          >
            <Clipboard className="w-3.5 h-3.5 text-neutral-400" />
            <span>粘贴</span>
          </button>

          <button
            id="btn-upload-file"
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs transition-colors"
            title="上传 Markdown 文件"
          >
            <Upload className="w-3.5 h-3.5 text-neutral-400" />
            <span>导入文件</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".md,.txt,.markdown"
            className="hidden"
          />

          <button
            id="btn-clear-input"
            onClick={() => onChange('')}
            className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-red-400 transition-colors"
            title="清空内容"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Preset selector bar */}
      <div className="px-3 py-2 bg-neutral-950/40 border-b border-neutral-800/80 flex items-center gap-2 overflow-x-auto text-xs">
        <span className="text-[11px] text-neutral-400 flex items-center gap-1 shrink-0">
          <BookOpen className="w-3 h-3 text-purple-400" />
          快捷载入测试样例:
        </span>
        {PRESET_SAMPLES.map((sample) => (
          <button
            key={sample.id}
            onClick={() => onLoadPreset(sample.id)}
            className={`px-2.5 py-1 rounded-md text-xs whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activePresetId === sample.id
                ? 'bg-purple-600/30 text-purple-200 border border-purple-500/50'
                : 'bg-neutral-800/60 hover:bg-neutral-800 text-neutral-300 border border-neutral-700/40'
            }`}
          >
            <span>{sample.title}</span>
            <span className="text-[10px] px-1 py-0.2 bg-neutral-700/50 rounded text-neutral-400">
              {sample.badge}
            </span>
          </button>
        ))}
      </div>

      {/* Text Area */}
      <div className="relative flex-1 min-h-[350px]">
        <textarea
          id="chatgpt-input-textarea"
          value={input}
          onChange={(e) => onChange(e.target.value)}
          placeholder="在此处直接粘贴从 ChatGPT 复制出来的带有公式的笔记内容..."
          className="w-full h-full p-4 bg-neutral-950/50 text-neutral-200 font-mono text-xs leading-relaxed resize-none focus:outline-none focus:ring-1 focus:ring-purple-500/50 selection:bg-purple-900/40"
          spellCheck={false}
        />
      </div>

      {/* Quick Settings Footer */}
      <div className="px-4 py-2 bg-neutral-950/70 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400 flex-wrap gap-2">
        <div className="flex items-center gap-3 flex-wrap">
          <label className="flex items-center gap-1.5 cursor-pointer hover:text-neutral-200">
            <input
              type="checkbox"
              checked={options.cleanDuplicatePrefixes}
              onChange={(e) =>
                onOptionsChange({ ...options, cleanDuplicatePrefixes: e.target.checked })
              }
              className="rounded border-neutral-700 text-purple-600 focus:ring-0 w-3.5 h-3.5 bg-neutral-800"
            />
            <span>清理 DOM 重复前缀</span>
          </label>

          <label className="flex items-center gap-1.5 cursor-pointer hover:text-neutral-200">
            <input
              type="checkbox"
              checked={options.fixInlineDuplicates}
              onChange={(e) =>
                onOptionsChange({ ...options, fixInlineDuplicates: e.target.checked })
              }
              className="rounded border-neutral-700 text-purple-600 focus:ring-0 w-3.5 h-3.5 bg-neutral-800"
            />
            <span>修复行内重复 ($H^+$)</span>
          </label>

          <label className="flex items-center gap-1.5 cursor-pointer hover:text-neutral-200">
            <input
              type="checkbox"
              checked={options.convertBracketDelimiters}
              onChange={(e) =>
                onOptionsChange({ ...options, convertBracketDelimiters: e.target.checked })
              }
              className="rounded border-neutral-700 text-purple-600 focus:ring-0 w-3.5 h-3.5 bg-neutral-800"
            />
            <span>转换 \[ \] 与 \( \)</span>
          </label>
        </div>

        <div className="text-[11px] text-neutral-500 flex items-center gap-1">
          <Layers className="w-3 h-3 text-neutral-400" />
          <span>Obsidian 兼容模式</span>
        </div>
      </div>
    </div>
  );
};
