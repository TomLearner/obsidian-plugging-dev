import React, { useState } from 'react';
import { Eye, Code, GitCompare, Download, Check, Copy, ExternalLink, HelpCircle, AlertCircle, FileArchive } from 'lucide-react';
import { MarkdownRenderer } from './MarkdownRenderer';
import { ConversionStats, FixLogItem } from '../types';
import { PLUGIN_MANIFEST, PLUGIN_MAIN_JS, PLUGIN_CSS, generatePluginZip } from '../utils/obsidianPluginCode';

interface PreviewPaneProps {
  output: string;
  originalInput: string;
  stats: ConversionStats;
  logs: FixLogItem[];
  onCopyResult: () => void;
  copied: boolean;
}

export const PreviewPane: React.FC<PreviewPaneProps> = ({
  output,
  originalInput,
  stats,
  logs,
  onCopyResult,
  copied,
}) => {
  const [activeTab, setActiveTab] = useState<'preview' | 'markdown' | 'diff' | 'plugin'>('preview');
  const [copiedFile, setCopiedFile] = useState<string | null>(null);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  const handleDownloadZip = async () => {
    try {
      setIsDownloadingZip(true);
      const blob = await generatePluginZip();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'obsidian-chatgpt-latex-fixer.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Failed to create plugin zip', e);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  const copyPluginCode = (filename: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedFile(filename);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm">
      {/* Tab Navigation Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-neutral-900/90 border-b border-neutral-800 flex-wrap gap-2">
        <div className="flex items-center gap-1 bg-neutral-950/60 p-1 rounded-lg border border-neutral-800/80">
          <button
            id="tab-preview"
            onClick={() => setActiveTab('preview')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'preview'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Obsidian 渲染预览</span>
          </button>

          <button
            id="tab-markdown"
            onClick={() => setActiveTab('markdown')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'markdown'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>转换后 Markdown</span>
          </button>

          <button
            id="tab-diff"
            onClick={() => setActiveTab('diff')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'diff'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <GitCompare className="w-3.5 h-3.5" />
            <span>修改对比 ({logs.length})</span>
          </button>

          <button
            id="tab-plugin"
            onClick={() => setActiveTab('plugin')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              activeTab === 'plugin'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span className="text-purple-300 font-semibold">插件源码与安装包</span>
          </button>
        </div>

        {activeTab === 'markdown' && (
          <button
            onClick={onCopyResult}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs transition-colors border border-neutral-700/60"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? '已复制到剪贴板' : '复制代码'}</span>
          </button>
        )}
      </div>

      {/* Tab Contents */}
      <div className="flex-1 overflow-y-auto min-h-[350px] bg-neutral-950/40">
        {/* TAB 1: PREVIEW */}
        {activeTab === 'preview' && (
          <div className="h-full">
            {output ? (
              <div className="max-w-3xl mx-auto">
                <MarkdownRenderer content={output} />
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center p-8 text-center text-neutral-500">
                <AlertCircle className="w-10 h-10 mb-3 text-neutral-600" />
                <p className="text-sm font-medium">暂无渲染内容</p>
                <p className="text-xs mt-1 text-neutral-500">
                  请在左侧粘贴从 ChatGPT 复制的内容，或点击上方预设测试样例
                </p>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: MARKDOWN RAW */}
        {activeTab === 'markdown' && (
          <div className="h-full p-4">
            <pre className="w-full h-full font-mono text-xs text-neutral-300 leading-relaxed overflow-x-auto select-all whitespace-pre-wrap">
              {output || '// 转换后的 Markdown 将显示在此处'}
            </pre>
          </div>
        )}

        {/* TAB 3: DIFF & DIAGNOSTICS */}
        {activeTab === 'diff' && (
          <div className="p-4 space-y-4 max-w-4xl mx-auto">
            <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4">
              <h3 className="text-sm font-semibold text-neutral-200 mb-1 flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-purple-400" />
                ChatGPT 公式无法在 Obsidian 中显示的根本原因
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed mt-2">
                ChatGPT 网页端采用 KaTeX 渲染数学公式，其 DOM 结构中同时包含<strong>可渲染文本层</strong>与<strong>原始 LaTeX 源码层</strong>。当用户通过鼠标划选复制时，浏览器剪贴板会将两层内容拼接在一起，形成例如{' '}
                <code className="bg-neutral-800 px-1 py-0.5 rounded text-amber-300">
                  CH3COOH\mathrm&#123;CH_3COOH&#125;
                </code>{' '}
                或{' '}
                <code className="bg-neutral-800 px-1 py-0.5 rounded text-amber-300">
                  H+H^+
                </code>{' '}
                的拼接字符串。此外，ChatGPT 的块级公式常使用未定界的单独命令，缺少 Obsidian 所必需的{' '}
                <code className="text-purple-300">$$...$$</code> 与{' '}
                <code className="text-purple-300">$...$</code> 定界符。
              </p>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-neutral-300">
                检测到的修复项列表 ({logs.length} 项)
              </span>
            </div>

            {logs.length === 0 ? (
              <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-6 text-center text-xs text-neutral-500">
                当前文本中未发现需要修复的 ChatGPT 异常公式。
              </div>
            ) : (
              <div className="space-y-2.5">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="bg-neutral-900/90 border border-neutral-800 rounded-lg p-3 text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-mono text-purple-400 font-semibold">
                        第 {log.lineNumber} 行
                      </span>
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] uppercase font-bold ${
                          log.type === 'block'
                            ? 'bg-blue-950 text-blue-300 border border-blue-800'
                            : log.type === 'inline'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        }`}
                      >
                        {log.type}
                      </span>
                    </div>

                    <p className="text-neutral-400 text-[11px]">{log.explanation}</p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 font-mono text-[11px] pt-1">
                      <div className="bg-red-950/20 border border-red-900/40 rounded p-2 text-red-300 overflow-x-auto">
                        <span className="text-red-500 font-bold block text-[10px] mb-1">
                          - 原始文本 (ChatGPT)
                        </span>
                        {log.original}
                      </div>
                      <div className="bg-emerald-950/20 border border-emerald-900/40 rounded p-2 text-emerald-300 overflow-x-auto">
                        <span className="text-emerald-500 font-bold block text-[10px] mb-1">
                          + 修复为标准 LaTeX (Obsidian)
                        </span>
                        {log.fixed}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: OBSIDIAN PLUGIN EXPORT */}
        {activeTab === 'plugin' && (
          <div className="p-5 max-w-4xl mx-auto space-y-6">
            {/* Quick Download Hero */}
            <div className="bg-gradient-to-r from-purple-950/60 to-neutral-900 border border-purple-800/40 rounded-xl p-5 flex flex-col md:flex-row items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-white">
                    ChatGPT LaTeX Fixer for Obsidian
                  </h3>
                  <span className="px-2 py-0.5 text-[10px] bg-purple-600 text-white rounded font-bold">
                    官方规范插件
                  </span>
                </div>
                <p className="text-xs text-neutral-300 mt-1 max-w-xl">
                  开箱即用的 Obsidian 社区插件安装包。支持在 Obsidian 内部一键修复当前笔记、修复选中区域、或在剪贴板粘贴时自动拦截修复。
                </p>
              </div>

              <button
                id="btn-download-plugin-zip"
                onClick={handleDownloadZip}
                disabled={isDownloadingZip}
                className="shrink-0 flex items-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-semibold shadow-lg shadow-purple-900/30 transition-all hover:scale-105"
              >
                <FileArchive className="w-4 h-4" />
                <span>{isDownloadingZip ? '正在打包...' : '下载插件压缩包 (.zip)'}</span>
              </button>
            </div>

            {/* Step-by-step tutorial */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 space-y-3">
              <h4 className="text-xs font-bold text-neutral-200 uppercase tracking-wider">
                Obsidian 手动安装教程 (4 步快速启用)
              </h4>
              <ol className="space-y-2.5 text-xs text-neutral-300">
                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-purple-900/60 text-purple-300 flex items-center justify-center shrink-0 font-bold text-[11px]">
                    1
                  </span>
                  <div>
                    打开你的 Obsidian 仓库，进入插件目录：
                    <code className="bg-neutral-800 text-purple-300 px-2 py-0.5 rounded font-mono ml-1">
                      .obsidian/plugins/
                    </code>
                  </div>
                </li>

                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-purple-900/60 text-purple-300 flex items-center justify-center shrink-0 font-bold text-[11px]">
                    2
                  </span>
                  <div>
                    在 plugins 目录下新建文件夹：
                    <code className="bg-neutral-800 text-purple-300 px-2 py-0.5 rounded font-mono ml-1">
                      obsidian-chatgpt-latex-fixer
                    </code>
                  </div>
                </li>

                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-purple-900/60 text-purple-300 flex items-center justify-center shrink-0 font-bold text-[11px]">
                    3
                  </span>
                  <div>
                    解压下载的 zip 压缩包，将里面的{' '}
                    <span className="text-white font-medium">manifest.json</span>、
                    <span className="text-white font-medium">main.js</span>、
                    <span className="text-white font-medium">styles.css</span> 放入该文件夹。
                  </div>
                </li>

                <li className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-purple-900/60 text-purple-300 flex items-center justify-center shrink-0 font-bold text-[11px]">
                    4
                  </span>
                  <div>
                    在 Obsidian 中打开「设置」→「第三方插件 (Community plugins)」→ 点击「重新加载已安装插件」，找到{' '}
                    <strong className="text-purple-300">ChatGPT LaTeX Fixer</strong> 并点击启用开关！
                  </div>
                </li>
              </ol>
            </div>

            {/* Plugin Source Code Viewers */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-neutral-200 uppercase tracking-wider">
                插件源码查看与一键复制 (Plugin Files)
              </h4>

              {/* main.js */}
              <div className="border border-neutral-800 rounded-lg overflow-hidden bg-neutral-900">
                <div className="flex items-center justify-between px-3 py-2 bg-neutral-950/80 border-b border-neutral-800">
                  <span className="text-xs font-mono text-purple-300 font-semibold">
                    main.js (插件核心运行时)
                  </span>
                  <button
                    onClick={() => copyPluginCode('main.js', PLUGIN_MAIN_JS)}
                    className="flex items-center gap-1 text-xs text-neutral-400 hover:text-white px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700"
                  >
                    {copiedFile === 'main.js' ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                    <span>{copiedFile === 'main.js' ? '已复制' : '复制 main.js'}</span>
                  </button>
                </div>
                <div className="max-h-52 overflow-y-auto p-3 font-mono text-[11px] text-neutral-300 bg-neutral-950/40">
                  <pre>{PLUGIN_MAIN_JS}</pre>
                </div>
              </div>

              {/* manifest.json */}
              <div className="border border-neutral-800 rounded-lg overflow-hidden bg-neutral-900">
                <div className="flex items-center justify-between px-3 py-2 bg-neutral-950/80 border-b border-neutral-800">
                  <span className="text-xs font-mono text-purple-300 font-semibold">
                    manifest.json (插件元数据)
                  </span>
                  <button
                    onClick={() =>
                      copyPluginCode('manifest.json', JSON.stringify(PLUGIN_MANIFEST, null, 2))
                    }
                    className="flex items-center gap-1 text-xs text-neutral-400 hover:text-white px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700"
                  >
                    {copiedFile === 'manifest.json' ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                    <span>{copiedFile === 'manifest.json' ? '已复制' : '复制 manifest.json'}</span>
                  </button>
                </div>
                <div className="p-3 font-mono text-[11px] text-neutral-300 bg-neutral-950/40">
                  <pre>{JSON.stringify(PLUGIN_MANIFEST, null, 2)}</pre>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer bar */}
      <div className="px-4 py-2 bg-neutral-950/70 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
        <div className="flex items-center gap-2">
          <span>Obsidian KaTeX 渲染引擎</span>
          <span className="text-neutral-600">·</span>
          <span className="text-emerald-400">LaTeX 标准校验通过</span>
        </div>
        <div>
          <span>已处理: {output ? output.length : 0} 字符</span>
        </div>
      </div>
    </div>
  );
};
