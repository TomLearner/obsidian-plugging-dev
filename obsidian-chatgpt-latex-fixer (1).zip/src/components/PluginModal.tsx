import React, { useState } from 'react';
import { X, Download, FileArchive, Check, Copy, Folder, Terminal, Sparkles } from 'lucide-react';
import { PLUGIN_MANIFEST, PLUGIN_MAIN_JS, PLUGIN_CSS, generatePluginZip } from '../utils/obsidianPluginCode';

interface PluginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PluginModal: React.FC<PluginModalProps> = ({ isOpen, onClose }) => {
  const [downloading, setDownloading] = useState(false);
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    try {
      setDownloading(true);
      const blob = await generatePluginZip();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'obsidian-chatgpt-latex-fixer.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Download failed', e);
    } finally {
      setDownloading(false);
    }
  };

  const copyToClipboard = (filename: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedFile(filename);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-600/20 text-purple-400 flex items-center justify-center font-bold">
              fx
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Obsidian 插件包导出与安装向导</h3>
              <p className="text-xs text-neutral-400">一键下载或手动复制插件至你的 Obsidian Vault</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-neutral-300">
          {/* Download Action Card */}
          <div className="bg-gradient-to-br from-purple-950/40 via-neutral-900 to-neutral-900 border border-purple-800/40 rounded-xl p-4 flex items-center justify-between gap-4">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-400" />
                下载完整插件安装包 (ZIP)
              </h4>
              <p className="text-xs text-neutral-400 mt-1">
                包含 manifest.json、main.js、styles.css 及 README 说明文档。
              </p>
            </div>
            <button
              onClick={handleDownloadZip}
              disabled={downloading}
              className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg font-medium transition-all shadow-md shrink-0"
            >
              <FileArchive className="w-4 h-4" />
              <span>{downloading ? '打包中...' : '立即下载 (.zip)'}</span>
            </button>
          </div>

          {/* Installation Steps */}
          <div className="space-y-2">
            <h4 className="font-semibold text-neutral-200">快速安装步骤：</h4>
            <div className="bg-neutral-950/70 border border-neutral-800 rounded-lg p-3 space-y-2 text-neutral-300">
              <div className="flex items-start gap-2">
                <span className="font-mono text-purple-400 font-bold">1.</span>
                <span>
                  定位至你的 Obsidian 笔记仓库：
                  <code className="text-purple-300 bg-neutral-900 px-1.5 py-0.5 rounded ml-1">
                    YourVault/.obsidian/plugins/
                  </code>
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-mono text-purple-400 font-bold">2.</span>
                <span>
                  新建名为 <strong className="text-white">obsidian-chatgpt-latex-fixer</strong> 的文件夹。
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-mono text-purple-400 font-bold">3.</span>
                <span>将解压得到的 3 个文件放入该文件夹中。</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-mono text-purple-400 font-bold">4.</span>
                <span>在 Obsidian「设置 → 第三方插件」中点击刷新，并开启本插件。</span>
              </div>
            </div>
          </div>

          {/* Files Copy Section */}
          <div className="space-y-2">
            <h4 className="font-semibold text-neutral-200">手动复制文件内容：</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                onClick={() => copyToClipboard('main.js', PLUGIN_MAIN_JS)}
                className="flex items-center justify-between p-3 rounded-lg bg-neutral-800/60 hover:bg-neutral-800 border border-neutral-700/50 text-left transition-colors"
              >
                <div>
                  <div className="font-mono font-medium text-neutral-200 text-xs">main.js</div>
                  <div className="text-[11px] text-neutral-400">插件核心执行代码</div>
                </div>
                {copiedFile === 'main.js' ? (
                  <Check className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Copy className="w-4 h-4 text-neutral-400" />
                )}
              </button>

              <button
                onClick={() =>
                  copyToClipboard('manifest.json', JSON.stringify(PLUGIN_MANIFEST, null, 2))
                }
                className="flex items-center justify-between p-3 rounded-lg bg-neutral-800/60 hover:bg-neutral-800 border border-neutral-700/50 text-left transition-colors"
              >
                <div>
                  <div className="font-mono font-medium text-neutral-200 text-xs">manifest.json</div>
                  <div className="text-[11px] text-neutral-400">插件版本与配置</div>
                </div>
                {copiedFile === 'manifest.json' ? (
                  <Check className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Copy className="w-4 h-4 text-neutral-400" />
                )}
              </button>
            </div>
          </div>

          {/* Obsidian Commands Guide */}
          <div className="space-y-1.5 bg-neutral-950/40 p-3 rounded-lg border border-neutral-800/80">
            <h5 className="font-semibold text-neutral-200">内置功能与快捷指令：</h5>
            <ul className="space-y-1 list-disc list-inside text-neutral-400 text-[11px]">
              <li>
                <strong className="text-neutral-200">粘贴自动修复</strong>：在 Obsidian 笔记中直接按 Ctrl+V 粘贴 ChatGPT 内容，插件自动替换为标准公式。
              </li>
              <li>
                <strong className="text-neutral-200">命令面板 (Ctrl/Cmd + P)</strong>：输入 <code>Fix ChatGPT LaTeX in current note</code> 修复全篇笔记。
              </li>
              <li>
                <strong className="text-neutral-200">划选修复</strong>：选中局部段落执行 <code>Fix ChatGPT LaTeX in selection</code> 仅修复选中区域。
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-neutral-950/80 border-t border-neutral-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium transition-colors"
          >
            完成
          </button>
        </div>
      </div>
    </div>
  );
};
