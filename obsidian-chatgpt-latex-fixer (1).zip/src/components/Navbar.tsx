import React from 'react';
import { Sparkles, Download, Copy, RefreshCw, FileText, Settings, Check } from 'lucide-react';
import { ConversionStats } from '../types';

interface NavbarProps {
  stats: ConversionStats;
  onConvert: () => void;
  onCopyResult: () => void;
  onDownloadMarkdown: () => void;
  onOpenPluginModal: () => void;
  copied: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  stats,
  onConvert,
  onCopyResult,
  onDownloadMarkdown,
  onOpenPluginModal,
  copied,
}) => {
  return (
    <header className="border-b border-neutral-800 bg-neutral-900/90 backdrop-blur sticky top-0 z-30 px-4 py-3">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-400 shadow-sm">
              <span className="font-serif font-bold text-lg">fx</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-neutral-100 tracking-tight">
                  Obsidian ChatGPT LaTeX Fixer
                </h1>
                <span className="px-2 py-0.5 text-[11px] font-medium bg-purple-950/60 text-purple-300 border border-purple-800/60 rounded-full">
                  v1.0.0 Plugin
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                自动识别并修复 ChatGPT 复制到 Obsidian 中错乱与缺失的公式
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end flex-wrap">
          {stats.totalFixes > 0 && (
            <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-950/40 border border-emerald-800/40 text-emerald-300 text-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>已修复 <strong>{stats.totalFixes}</strong> 处公式 ({stats.timeTakenMs}ms)</span>
            </div>
          )}

          <button
            id="btn-reconvert"
            onClick={onConvert}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium transition-colors border border-neutral-700/60"
            title="重新解析当前文本"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>重新转换</span>
          </button>

          <button
            id="btn-copy-result"
            onClick={onCopyResult}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
              copied
                ? 'bg-emerald-600 text-white border-emerald-500'
                : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border-neutral-700/60'
            }`}
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? '已复制' : '复制结果'}</span>
          </button>

          <button
            id="btn-download-md"
            onClick={onDownloadMarkdown}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium transition-colors border border-neutral-700/60"
            title="导出为标准 Markdown 文件"
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">导出 .md</span>
          </button>

          <button
            id="btn-plugin-installer"
            onClick={onOpenPluginModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-medium transition-all shadow-sm hover:shadow-purple-600/20"
          >
            <Download className="w-3.5 h-3.5" />
            <span>下载 Obsidian 插件</span>
          </button>
        </div>
      </div>
    </header>
  );
};
